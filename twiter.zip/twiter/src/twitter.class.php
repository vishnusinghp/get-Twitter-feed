<?php

require_once __DIR__ . '/OAuth.php';
require_once __DIR__ . '/Twitter.php';
/*$api = new Twitter();
$this->consumerKey = 	'IaatadhVgEsliZLcg2xTDjSkw';
$this->consumerSecret= 	'Le1NtV7yycSBMFUrLn6ndqZTpuNfbnMzTxvRmHx8A1Ajte3AxK';
$this->accessToken = '1201484034800418818-MFO0Cpl5PTWuHQrUjLaZBO3xIzM4pW';
$this->accessTokenSecret = 	'lVghwBHQpJPO7SnuK94rKIfLI2XCSTTC697yPKIGDsyN5';*/

