<?php
error_reporting(0);
header('Content-type:application/json');
//ini_set('display_errors', 1);
require_once('TwitterAPIExchange.php');

/** Set access tokens here - see: https://dev.twitter.com/apps/ **/
$settings = array(
    'oauth_access_token' => "71428719-McR2uCmb3CdoaBR1nijh8RaO5986N3EFDAd8ALm9E",
    'oauth_access_token_secret' => "7yBH8LT2rDmfeBcXTJWF1laFLc7HeKFKlcNCjbl6nEefP",
    'consumer_key' => "BqRq0mtfFAw0YhGX458hd7x6w",
    'consumer_secret' => "kAl1gDVGbPmYoG6UWr2kIFu4VWSDTe1B1iORlSQZiptxDmhVic"
);

$url = 'https://api.twitter.com/1.1/statuses/user_timeline.json';
$getfield = '?screen_name=mojksa&skip_status=1&include_entities=true&count=100';
$requestMethod = 'GET';
$twitter = new TwitterAPIExchange($settings);
$data =  $twitter->setGetfield($getfield)
             ->buildOauth($url, $requestMethod)
             ->performRequest();  



$e = json_decode($data,TRUE);


foreach($e as $key => $value)
{
    

   // if($value['entities']['media']):
    
    $media = array();
    foreach($value['entities']['media'] as $m )
    {
        $media[] = array('url'=>$m['media_url']);
    }
    
   // else:
    
   // $media = '';
    
    
   // endif;

     $json['tweets'][] = array('name' => $value['user']['name'],'screen_name'=>$value['user']['screen_name'], 'created_at'=>$value['created_at'],'text'=>$value['text'],'media'=>$media);

    
}

//$json['tweets'][] = array('name' => 'A','screen_name'=>'mojksa', 'created_at');


echo json_encode($json);
